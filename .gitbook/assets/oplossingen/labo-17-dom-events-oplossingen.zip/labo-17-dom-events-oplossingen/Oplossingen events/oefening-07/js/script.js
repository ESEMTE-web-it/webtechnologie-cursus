"use strict"

let color = window.getComputedStyle(
  document.querySelector("#bg-grey")
).backgroundColor;

console.log(color);
