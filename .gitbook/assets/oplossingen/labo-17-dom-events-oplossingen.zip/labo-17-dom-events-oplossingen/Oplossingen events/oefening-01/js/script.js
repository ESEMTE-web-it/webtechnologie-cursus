"use strict";

const newText = "Welkom op onze website";
document.querySelector("#title").innerText = newText;
