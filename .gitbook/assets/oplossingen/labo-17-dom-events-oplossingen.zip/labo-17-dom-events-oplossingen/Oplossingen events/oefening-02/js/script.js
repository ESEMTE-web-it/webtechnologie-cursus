"use strict";

console.log(document.querySelector("#myImage").src);
