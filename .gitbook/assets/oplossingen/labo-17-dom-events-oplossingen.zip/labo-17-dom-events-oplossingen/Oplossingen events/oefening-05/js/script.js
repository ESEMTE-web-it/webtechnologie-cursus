"use strict";

let item = document.querySelectorAll("li")[3];
let container = item.parentNode;
container.removeChild(item);
