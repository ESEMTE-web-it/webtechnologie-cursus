"use strict";

const newSource = "assets/images/nieuwe-afbeelding.png";
document.querySelector("#myImage").src = newSource;
