"use strict";

console.log(document.querySelectorAll("p")[0].textContent);
