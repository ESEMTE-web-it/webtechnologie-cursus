"use strict";

const RED = "rgb(255,70,0)";
const BLUE = "rgb(20,20,255)";

let p1 = document.querySelector("#red");
p1.style.color = RED;

let p2 = document.querySelector("#blue");
p2.style.color = BLUE;
