"use strict";
let myName = "Sven Maes";
let myAge = "33";
let myEmail = "sven.maes@ap.be";
let myGroup = "G_1PRO_Dx";

console.log("Naam: " + myName);
console.log("Leeftijd: " + myAge);
console.log("E-mailadres: " + myEmail);
console.log("Klasgroep: " + myGroup);

// Je kunt hetzelfde bereiken met:
// console.log("Naam: ", myName);
// console.log("Leeftijd: ", myAge);
// console.log("E-mailadres: ", myEmail);
// console.log("Klasgroep: ", myGroup);
