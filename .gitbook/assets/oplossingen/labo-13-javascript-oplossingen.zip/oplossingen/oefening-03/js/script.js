"use strict";
let myBirthYear = 1990;
let myAge = 2023 - myBirthYear;

console.log(myAge);