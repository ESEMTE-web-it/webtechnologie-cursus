"use strict";
let welcome = "Hello world!";
console.log(welcome);