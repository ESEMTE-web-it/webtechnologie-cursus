const colorblindText =
  "roses are blue, violets are red, grass is yellow, don't be so mean.";
let newText = colorblindText.replace("blue", "red").replace("yellow", "green");

console.log(colorblindText);
console.log("=");
console.log(newText);
